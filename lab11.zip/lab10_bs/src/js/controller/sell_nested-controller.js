'use strict';

/**
 * Sell Nested Controller handles the toggling of the nested views being shown
 **/
app.controller('SellNestedController', 
	['$scope', function($scope) {
 	
 	//Open a collapesed nested view if a state change occurs
 	//	This always takes place after the isCollapsed method
 	$scope.$on('$stateChangeSuccess', 
 		function(eventObject, toStateObject, toParams, fromStateObject, fromParams) {
			
		//Make sure the ui-view is able to be seen on any state change
		$scope.collapseView.isCollapsed = false;

 	});

 	//Toggling collapsed. Works in tandem with the state change success above
 	$scope.isCollapsed = function() {
 		$scope.collapseView.isCollapsed = !$scope.collapseView.isCollapsed;
 	};

}]);