'use strict';

//1- If we load 'aModule' then we have access to its methods
//var app = angular.module('ocLazyLoad', ['aModule']);

//2- Without 'aModule' loaded we don't have access to its methods
var app = angular.module('ocLazyLoad', []);

//3- If we lazy load it we have access to it again
//	- We no longer need to include module's JS in index.html
//var app = angular.module('ocLazyLoad', ['oc.lazyLoad']);

//Basic controller doing some lazy loading
app.controller('HomeController', 
	//Use this for example 1 & 2
	['$scope', '$injector', 
		function($scope, $injector) {

	//Use this for example 3
	// ['$scope', '$injector', '$ocLazyLoad',
	// 	function($scope, $injector, $ocLazyLoad) {

	console.log('Home Controller instantiated');

	$scope.interactWithModule = function() {

		//Use this for example 3
		// $ocLazyLoad.load({
		// 	//Name of the module we want to lazy load
		// 	name: 'aModule',
		// 	//Files only needed if the module is externally being loaded
		// 	files: ['js/module.js']
		// }).then(function() {
		// 	//We still have access to the module because it is being lazy loaded
		// 	console.log($injector.get('foo'));
		// });

		//Use this for example 1 & 2
		console.log($injector.get('foo'));
	};

}]);
