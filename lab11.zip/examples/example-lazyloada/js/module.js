'use strict';
var mod = angular.module('aModule', []);

mod.factory('foo', function() {
	return {
		bar: function() {
			console.log('Foo-bar');
		}
	};
});
