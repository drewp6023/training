'use strict';
/**
 *  First directive fun.
 **/
app.directive('diFirst', function() {
    return {
        priority: 3,
        //terminal: true,
        link: function(scope, instanceElement) {
            var listElement = angular.element('<li>First is a go...</li>');
            instanceElement.append(listElement);
            instanceElement.parent().css({backgroundColor: 'orange'});
        }        
    };
});

/**
 *  Second directive fun.
 **/
app.directive('diSecond', function() {
    return {
        priority: 2,
        link: function(scope, instanceElement) {
            var listElement = angular.element('<li>Second is a go...</li>');
            instanceElement.append(listElement);
            instanceElement.parent().css({backgroundColor: 'pink'});
        }        
    };
});

/**
 *  Third directive fun.
 **/
app.directive('diThird', function() {
    return {
        priority: 10,
        link: function(scope, instanceElement) {
            instanceElement.append('<li>Third is a go...</li>');
            instanceElement.parent().css({backgroundColor: 'blue'});
        }        
    };      
});

/**
 *  Fourth directive fun.
 **/
app.directive('diFourth', function() {
    return {
        priority: 1000,
        terminal: true,
        link: function(scope, instanceElement) {
            instanceElement.append('<li>Fourth is solo...</li>');
            instanceElement.parent().css({backgroundColor: 'firebrick'});
        }        
    };      
});





