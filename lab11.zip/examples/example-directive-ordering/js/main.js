'use strict';

//Creating an angular app
var app = angular.module('lemonadeApp', []);


