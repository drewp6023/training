'use strict';

//Prototype to be used for city instances
var proto = {
  hasMayor: true,
  toString: function() {
    return this.name + ' has ' + this.population + ' people';
  }
};

//Factory Function to create instances
var makeCity = function(name, population) {
  //Creating object via proto 
  //  Shared between all instances
  var city = Object.create(proto);

  //Instance variables
  city.name = name;
  city.population = population;

  //Return the object instance
  return city;
};

var lansing = makeCity('Lansing', 110000);
var boulder = makeCity('Boulder', 103000);

console.log('Name: ' + lansing.name);
console.log('Population: ' + lansing.population);
console.log('Do you have a mayor: ' + lansing.hasMayor);
console.log(lansing.toString());
console.log(lansing instanceof Object);
console.log(lansing.constructor === Object);

console.log('Name: ' + boulder.name);
console.log('Population: ' + boulder.population);
console.log('Do you have a mayor: ' + boulder.hasMayor);
console.log(boulder.toString());
console.log(boulder instanceof Object);
console.log(boulder.constructor === Object);

//IE8 and below browsers
var objectCreate = function(objectPrototype) {
  if (!objectPrototype) { return {}; }
  function F() {}
  F.prototype = objectPrototype;
  return new F();
};
var newObject = objectCreate(proto);
console.log(newObject);
