'use strict';

//Constructor
function City(name, population) {
  //Instance variables
  this.name = name;
  this.population = population;
}

//Prototype shared across all city instances
City.prototype = {
  constructor: City,
  hasMayor: true,
  toString: function() {
    return this.name + ' has ' + this.population + ' people';
  }
};

var lansing = new City('Lansing', 110000);
var boulder = new City('Lansing', 103000);

console.log('Name: ' + lansing.name);
console.log('Population: ' + lansing.popluation);
console.log('Do you have a mayor: ' + lansing.hasMayor);
console.log(lansing.toString());
console.log(lansing instanceof City);
console.log(lansing instanceof Object);
console.log(lansing.constructor === City);

console.log('Name: ' + boulder.name);
console.log('Population: ' + boulder.popluation);
console.log('Do you have a mayor: ' + boulder.hasMayor);
console.log(boulder.toString());
console.log(boulder instanceof City);
console.log(boulder instanceof Object);
console.log(boulder.constructor === City);
