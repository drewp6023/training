'use strict';
function UrbanCenter(name, population) {
  this.name = name;
  this.population = population;
}

UrbanCenter.prototype = {
  constructor: UrbanCenter,
  hasMayor: true,
  toString: function() {
    return 'Urban Center with ' + this.population + ' people';
  }
};

//city is just a function
//  It uses the UrbanCenter constructor as if it was its own
//  We add properties after instantiating a new UrbanCenter
//  We need to return our new instance out of the city function
//    This new object will be of type UrbanCenter!
function city(name, population) {
  var that = new UrbanCenter(name, population);
  that.toString = function() {
    var superText = UrbanCenter.prototype.toString.call(this);
    return superText.replace('Urban Center', 'City');
  };
  return that;
}

//Doesn't need the new operator because it is just a function
var lansing = city('Lansing', 100000);
console.log('Name: ' + lansing.name);
console.log('Population: ' + lansing.population);
console.log('Do you have a mayor: ' + lansing.hasMayor);
console.log(lansing.toString());
console.log(lansing instanceof UrbanCenter);
console.log(lansing instanceof Object);
console.log(lansing.constructor === UrbanCenter);

//Doesn't need the new operator because it is just a function
var boulder = city('Boulder', 103000);
console.log('Name: ' + boulder.name);
console.log('Population: ' + boulder.population);
console.log('Do you have a mayor: ' + boulder.hasMayor);
console.log(boulder.toString());
console.log(boulder instanceof UrbanCenter);
console.log(boulder instanceof Object);
console.log(boulder.constructor === UrbanCenter);

//Creating the super class
var denver = new UrbanCenter('Denver', 650000);
console.log('Name: ' + denver.name);
console.log('Population: ' + denver.population);
console.log('Do you have a mayor: ' + denver.hasMayor);
console.log(denver.toString());
console.log(denver instanceof UrbanCenter);
console.log(denver instanceof Object);
console.log(denver.constructor === UrbanCenter);

