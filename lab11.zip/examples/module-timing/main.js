'use strict';

//Main module
var app = angular.module('demo', ['subModule']);

app.config(function(startTime, subStartTime) {
  console.log('Main module config: ' + startTime);
  console.log('Main module config sub: ' + subStartTime); 
});
app.run(function(startTime, subStartTime) {
  console.log('Main module run: ' + startTime);
  console.log('Main module run sub: ' + subStartTime);
});
app.constant('startTime', new Date().toLocaleTimeString());

//Sub module
angular.module('subModule', [])
  //Can we do this?
  // .config(function(startTime, subStartTime) {
  //   //We don't have access to the constants on the main module yet
  //   console.log('subModule config:' + startTime);
  //   console.log('subModule module config sub:' + subStartTime);
  // })
  .config(function(subStartTime) {
    console.log('subModule config: no time');
    console.log('subModule module config sub:' + subStartTime);
  })
  .constant('subStartTime', new Date().toLocaleTimeString())
  .run(function(startTime, subStartTime) {
    console.log('subModule module run: ' + startTime);
    console.log('subModule module run sub: ' + subStartTime);
  });
