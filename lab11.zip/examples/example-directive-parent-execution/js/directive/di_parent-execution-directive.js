'use strict';
/**
 *  Directive to be used across all page headers.
 **/
app.directive('diCar', function() {
	return {
        //Only allowing element and attribute implementations
		restrict: 'EA',
		scope: {
            //Parent execution binding strategy
			diAction: '&',
		},
        //Inline template for simplicity
    	template: '<button ng-click="callParentExecution()">Call Parent</button>',
    	/**
         * Handles user interaction with the directive.
         * @param scope: the scope connected with the directive
         * @param instanceElement: the rendered directive element
         **/
        link: function(scope, instanceElement) {
            //Could be written this way
           /*scope.callParentExecution = function() {
                scope.diAction({make: 'Toyota', model: 'Sienna'});
            }; */

            //Could also be written this way
    		instanceElement.children().bind('click', function() {
    			scope.$apply(function() {
                    scope.diAction({make: 'Toyota', model: 'Sienna'});
    			});	
    		});
    	}
	};
});





