'use strict';

var mod = angular.module('aModule', []);

mod.controller('ModuleController', function() {
	console.log('Module Controller instantiated');
});
