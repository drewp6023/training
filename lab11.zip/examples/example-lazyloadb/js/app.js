'use strict';

//Basic app
//1- Utilize injected module 'aModule' without lazy loading
//	- Need the JS file for the module app in the index.html
var app = angular.module('ocLazyLoad', ['ui.router', 'aModule']);
//2- Utilize ocLazyLoader for module loading
//	- No need for the JS for the module app in the index.html
//var app = angular.module('ocLazyLoad', ['ui.router', 'oc.lazyLoad']);

//Router Cofiguratoin
app.config(['$stateProvider', function($stateProvider) {
	$stateProvider.state('home', {
		url: '/',
		template: '<h1>Welcome Home</h1>',
		controller: 'HomeController'
	})
	.state('module', {
		url: '/module',
		templateUrl: 'module/module.html',
		controller: 'ModuleController' //,
		//2- In order to use the module we need to make sure it is loaded
		//	- resolve guarantees our module will be loaded before state is 
		//		transitioned into.
		// resolve: {
		// 	thisModule: function($ocLazyLoad) {
		// 		console.log('Resolve being called');
		// 		return $ocLazyLoad.load({
		// 			//Lazy Load our module
		// 			name: 'aModule',
		// 			//Location of JS file holding our module
		// 			files: ['module/module.js']
		// 		});
		// 	}
		// }
	});
}]);

//Basic controller 
app.controller('HomeController', function() {

	console.log('Home Controller instantiated');


});
