'use strict';

var app = angular.module('ocLazyLoad', ['ui.router', 'oc.lazyLoad']);

//Loading normal simple state
app.config(['$stateProvider', function($stateProvider) {
	$stateProvider.state('home', {
		url: '/',
		template: '<h1>Wecome Home</h1>',
		controller: 'HomeController'
	});
}]);

//Basic controller doing some lazy loading
app.controller('HomeController', 
	['$scope', '$compile', '$ocLazyLoad', 
		function($scope, $compile, $ocLazyLoad) {

	console.log('Home Controller instantiated');

	//If we set a break point before here we will notice that the 
	//	testApp module in testApp.js is not loaded yet
	$ocLazyLoad.load({
		name: 'testApp',
		files: ['js/testApp.js']
	}).then(function() {
		//Successs handler if the loader did work
		var el, elToAppend;
		//Creating our compiled say-hello directive element
		elToAppend = $compile('<say-hello to="world"></say-hello>')($scope);
		//Using jQuery for this ability :)
		el = angular.element('h1');
		el.append(elToAppend);
	}, function(e) {
		//Error handler if the loader didn't work appropriately
		console.log(e);
	});

}]);