'use strict';
var outerFunction = function () {
  var x = 42;

  function innerFunction() {
    console.log('In x: ' + x);
  }

  return innerFunction;
};
//The return value of innerFunction is assigned to closureReference
//  The execution context of the outerFunction is certitude and can’t be garbage collected as we might expect
var closureReferenceA = outerFunction();
var closureReferenceB = outerFunction();
var closureReferenceC = outerFunction();

//We are accessing the outerFunction scope even after it has executed
closureReferenceA();
closureReferenceB();
closureReferenceC();

//Garbage Collector will run
console.log('Utilize outerFunction without storing an execution context');
outerFunction();

//Garbage Collector runs
console.log('delete closureReferenceA');
closureReferenceA = null;

console.log('invoke closureReferenceA');
closureReferenceA();
