'use strict';
var textCreation = function(name, hairColor) {
  var person = name + ' has ' + hairColor;
  //What is going to be logged???
  console.log(person);
};


/***********  Broken  **************/
Not going to interact in the way we might expect
 ... broken :(
var addingHoversBroken = function() {

  var users = [
    {id: 'user0', name: 'Kamren', hairColor: 'brown'},
    {id: 'user1', name: 'Bekah', hairColor: 'brown'},
    {id: 'user2', name: 'Freddy', hairColor: 'blond'}
  ];

  for (var i=0; i<users.length; i++) {
    var person = users[i];
    document.getElementById(person.id).onmouseover = function() {
      //What person will be passed in?
      //  Not who you might expect
      textCreation(person.name, person.hairColor);      
    };

  }

  //Hmmm we can interact with person outside of "scope"
  //  Not really ... person is scope to the addingHovers function
  console.log('person: ' + person.name);

};
/***********  Broken: end  **************/

// /***********  Fixed  **************/
// //Going to interact in the way we expect
// //  ... fixed :)
// var textCreationCallback = function(name, hairColor) {
//   //We will have the correct execution context stored
//   //  These variables will be stored and utilized whenever the callback below is 
//   //  invoked (i.e. on every mouseover)
//   console.log('Initialization of closure- name:' + name + ' hairColor-' + hairColor);
//   return function() {
//     console.log('Using closure- name: ' + name + ' hairColor-' + hairColor);
//     textCreation(name, hairColor);
//   };
// };

// var addingHoversFixed = function() {
  
//   var users = [
//     {id: 'user0', name: 'Kamren', hairColor: 'brown'},
//     {id: 'user1', name: 'Bekah', hairColor: 'brown'},
//     {id: 'user2', name: 'Freddy', hairColor: 'blond'}
//   ];

//   for (var i=0; i<users.length; i++) {
//     var person = users[i];
//     //The callback gives us with a returned function gives us a closure around the 
//     //  correct execution context (i.e. the correct person ... no more just Freddy)
//     document.getElementById(person.id).onmouseover = textCreationCallback(person.name, person.hairColor);
//   }

//   //This person won't be the person utilized in each onmouseover interaction
//   console.log('person: ' + person.name);

// };

// /***********  Fixed: end  **************/

addingHoversBroken();
//addingHoversFixed();
