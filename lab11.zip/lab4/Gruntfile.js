'use strict';

module.exports = function(grunt) {

  // Load grunt tasks automatically
  require('load-grunt-tasks')(grunt);

  // Time how long tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  // Project configuration.
  grunt.initConfig({

    //Live watching
    watch: {
      scripts: {
        files: [
          'src/**/*.html',
          'src/**/*.js',
          'src/**/*.css'
        ],
        options: {
          livereload: true
        }
      }
    }

  });

  // Define the default task
  grunt.registerTask('default', [
    'watch'
  ]);  

};