'use strict';

angular.module('lemon', [
  'lemon.home',
  'lemon.sell',
  'ngNewRouter'
]).
  controller('AppController', ['$router', AppController]);

function AppController($router) {
  console.log('app router');
  console.log($router);

  $router.config([
    //{ path: '/',  component: 'home' },
    { path: '/home', component: 'home' },
    { path: '/sell', component: 'sell' }
  ]);
}