angular.module('sell.lemonade', []).
    controller('LemonadeController', ['$router', LemonadeController]);

function LemonadeController($router) {
	'use strict';

	console.log('lemonade router');
	console.log($router);

 	//Setting the template info properties
	this.info = {
		description: 'I love drinking this stuff',
		health: 'Little lemon ... lots of sugar!'
	};

}

