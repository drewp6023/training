angular.module('lemon.home', []).
    controller('HomeController', HomeController);

function HomeController() {
	'use strict';
	
	console.log('home router');
	// console.log($router);

 	//Setting the page properties
 	this.page = {
 		title: 'This one\'s on me'
 	};

}
