angular.module('sell.healthySnack', []).
    controller('HealthySnackController', HealthySnackController);

function HealthySnackController() {
	'use strict';

	//Setting the template info properties
	this.info = {
		description: 'An apple a day keeps the doctor away'
	};
}
