angular.module('lemon.sell', [
	'sell.lemonade',
	'sell.treat',
	'sell.healthySnack'
]).
    controller('SellController', SellController);

function SellController($router) {
	'use strict';

  	console.log('sell router');
  	console.log($router);

 	//Setting the page properties
 	this.page = {
 		title: 'Sell'
 	};

	$router.config([
		//{path: '/', component: 'lemonade'},
		{path: '/lemonade', component: 'lemonade'},
	 	{path: '/treat', component: 'treat'},
	 	{path: '/healthy-snack', component: 'healthySnack'}
  	]);

}

