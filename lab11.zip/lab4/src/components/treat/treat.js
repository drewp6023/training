angular.module('sell.treat', []).
    controller('TreatController', ['$router', TreatController]);

function TreatController() {
	'use strict';

 	//Setting the template info properties
	this.info = {
		lifeSpan: -42
	};

}

