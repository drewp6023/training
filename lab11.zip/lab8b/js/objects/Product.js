//DevelopIntelligence Namespace
(function() {
  'use strict';
  window.DI = window.DI || {};
}());

//Product Object treated as a module
DI.Product = (function(){
  'use strict';

  /**
   * Product constructor used to create a product instance.
   * @param type string product type (e.g. Apple, Doritos)
   * @param cost number of how much the product costs
   * @param quantityAvailable number of how much product we have available
   **/
  function Product(type, quantityAvailable, cost) {
    //Adding the variable type to each object instance
    this.type = type;

    //Adding the available quantity to each object instance
    this.quantityAvailable = quantityAvailable;

    //Adding the cost to each object instance
    this.cost = cost;
  }

  /**
   * Shared prototype object on every instance of Product.
   **/
  Product.prototype = {

    //Resetting the prototype constructor property to point Product not Object
    constructor: Product,

    /**
     * Get the type of the product.
     **/
    getType: function() {
      return this.type;
    },

    /**
     * Get the cost of the product.
     **/
    getCost: function() {
      return this.cost;
    },

    /**
     * Get the available quantity of the product.
     **/
    getAvailableQuantity: function() {
      return this.quantityAvailable;
    },

    /**
     * Stringify the product object.
     **/
    toString: function() {
      return this.type + ' product with quantity: ' + this.quantityAvailable + 
        ' cost: ' + this.cost;
    }
  };

  //Return reference to the Product Object Constructor
  return Product;
}());

app.value('Product', DI.Product);