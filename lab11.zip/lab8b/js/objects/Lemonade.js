//DevelopIntelligence Namespace
(function() {
  'use strict';
  window.DI = window.DI || {};
}());

//Lemonade Object treated as a module
DI.Lemonade = (function(DI){
	'use strict';

	/**
     * Product constructor used to create a product instance.
  	 * @param type string product type (e.g. Apple, Doritos)
     * @param quantityAvailable is how much product we have available
     * @param cost number of how much the product cost
     * @param secondaryCost is the cost of a medium lemonade
     **/
	function Lemonade(type, quantityAvailable, cost, secondaryCost){
		//Contstructor stealing
		//	Setting up a Lemonade instance via the Product Constructor
		DI.Product.call(this, type, quantityAvailable, cost);

		//Adding the secondary cost to each object instance
		this.secondaryCost = secondaryCost;
	}

  	/**
   	 * Shared prototype object on every instance of Lemonade.
   	 **/
	Lemonade.prototype = Object.create(DI.Product.prototype);
	
	//Resetting the prototype constructor property to point Lemonade not Product
	Lemonade.prototype.constructor = Lemonade;
	
	/**
     * Get the cost of the lemonade of a different size (e.g. medium).
     **/
	Lemonade.prototype.getSecondaryCost = function() {
		return this.secondaryCost;
	};

	/**
  	 * Stringify the lemonade object.
 	 **/
	Lemonade.prototype.toString = function() {
		//Supertype access
		var superText = DI.Product.prototype.toString.call(this);
  		
  		return superText.replace('product', 'lemonade') + ' medium cost: ' + this.secondaryCost;
	};

	//Return reference to the Lemonade Object Constructor
	return Lemonade;

}(DI));

app.value('Lemonade', DI.Lemonade);