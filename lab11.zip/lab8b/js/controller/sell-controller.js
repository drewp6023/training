'use strict';

/**
 * Sell Controller for the sell route.
 **/
 app.controller('SellController', 
 	['$scope', 'TransactionService', 
 		function($scope, TransactionService) {
 	
 	//Setting the page properties
 	$scope.page = {
 		title: 'Sell'
 	};

 	$scope.transaction = {
 		largeLemonadeQuantity: 0,
 		mediumLemonadeQuantity: 0,
 		healthySnackQuantity: 0,
 		treatQuantity: 0,
 		transactionQuantity: 0,
 		transactionCost: 0
 	};

 	/**
 	 * Action that clears out the entire transaction.
 	 **/
 	$scope.clearTransaction = function() {
 		TransactionService.clearCurrentTransaction();
 		$scope.transaction.largeLemonadeQuantity = TransactionService.getMediumLemonadeQuantity();
 		$scope.transaction.mediumLemonadeQuantity = TransactionService.getLargeLemonadeQuantity();
 		$scope.transaction.healthySnackQuantity = TransactionService.getHealthySnackQuantity();
 		$scope.transaction.treatQuantity = TransactionService.getTreatQuantity();
 		$scope.transaction.transactionQuantity = TransactionService.getCurrentTransactionQuantity();
 		$scope.transaction.transactionCost = TransactionService.getCurrentTransactionCost();
 	};

 	/**
 	 * Initialize the transaction service.
 	 **/
 	(function() {
 		//Healthy snack information
		var healthySnack = {
			type: 'Apple',
			availableQuantity: 30,
			cost: 2
		};

		//treat information
		var treat = {
			type: 'Doritos',
			availableQuantity: 20,
			cost: 2			
		};

		//lemonade information
		var lemonade = {
			type: 'Pink',
			availableQuantity: 20,
			cost: 2,
			secondaryCost: 1					
		};
 		//Interact with properties on response data
		TransactionService.intializeTransaction(
			healthySnack, treat, lemonade
		); 		
 	}());

 }]);