'use strict';

module.exports = function(grunt) {

  // Load grunt tasks automatically
  require('load-grunt-tasks')(grunt);
  // If something doesn't fit the glob pattern above
  //  require('load-grunt-tasks')(grunt, {pattern: 'grunt-*'});
  //  Include it like grunt-wiredep below
  //  grunt.loadNpmTasks('grunt-wiredep');

  // Time how long tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  // Project configuration.
  grunt.initConfig({

    // Automatically inject Bower components into the app
    wiredep: {
      app: {
        src: 'src/index.html',

        options: {
          dependencies: true,
          devDependencies: true
        }
      }
    }

  });

  // Define the default task
  grunt.registerTask('default', [
    'wiredep'
  ]);

};