'use strict';
/**
 *  Directive to be used across all page headers.
 **/
app.directive('lemonSalesHistory', ['chartGraph', function(chartGraph) {
	return {
		restrict: 'EA',
		scope: {
			lemonSales: '=',
			lemonLimit: '@'
		},
    	template: '<div>Sales History for last {{lemonLimit}} months<div class="graph"></div></div>',
    	link: function(scope, instanceElement, instanceAttributes) {
    		scope.sales = _.first(scope.lemonSales, [scope.lemonLimit]);
    		var salesProfit = [];

    		scope.$watch('lemonLimit', function(newVal) {
    			if(newVal) {
    			
    				salesProfit = [];
    				scope.sales = _.first(scope.lemonSales, [scope.lemonLimit]);

    				//Building up our sales numbers
    				angular.forEach(scope.sales, function(value) {
    					salesProfit.push(value.netSale);
    				});

    				chartGraph.graphIt(instanceElement, salesProfit, instanceAttributes);

    			}
    		});
    	}
	};
}]);

/**
 * Factory service to draw out D3 for sales history
 **/
app.factory('chartGraph', function() {

	var graphIt = function(element, data, options) {
		var width = options.width || 400;
		var height = options.height || 200;

		d3.select('svg').remove();

		var svg = d3.select(element[0])
					.append('svg:svg')
					.attr('width', width)
					.attr('height', height)
					.attr('class', 'salesHistory')
					.append('g');

		//Getting the max value the y can be set to
		var maxY = d3.max(data);

		var x = d3.scale.linear()
					.domain([0, data.length-1])
					.range([0, width]);

		var y = d3.scale.linear()
					.domain([0, maxY])
					.range([height, 0]);

		//Setting up the y-axis
		var yAxis = d3.svg.axis().scale(y)
					.orient('left')
					.ticks(5);

		//Setting up the x-axis
		var xAxis = d3.svg.axis().scale(x)
					.orient('below')
					.ticks(5);

	    //adding y-axis
		svg.append('g')
			.attr('class', 'y axis')
			.call(yAxis);

		//adding x-axis
		svg.append('g')
			.attr('class', 'x axis')
			.attr('transform', 'translate(0,' + height + ')')
			.call(xAxis);	

		//adding x-axis text
		svg.append('text')
			.attr('x', width/2)
			.attr('y', height + 50)
			.style('text-anchor', 'middle')
			.text('Months');	

		//adding y-axis text
		svg.append('text')
			.attr('transform', 'rotate(-90)')
			.attr('y', -70)
			.attr('x', 0 -(height / 2))
			.style('text-anchor', 'middle')
			.text('Net Profit');

		//How the line will be drawn on the path
		var line = d3.svg.line()
					.interpolate('linear')
					.x(function(d,i){
						return x(i);
					})
					.y(function(d,i){
						return y(d);
					});

		//The path the line will traverse
		var path = svg.append('svg:path')
					.data([data])
					.attr('d', line)
					.attr('fill', 'none')
					.attr('stroke-width', '1');

	};

	return {
		graphIt: graphIt
	};

});

