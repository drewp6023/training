'use strict';

//Creating an angular app
var app = angular.module('lemonadeApp', ['ui.router']);

/**
 * Configure our application to give us basic routing
 **/
app.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/');

	$stateProvider
		.state('home', {
			url:'/',
			templateUrl: 'templates/home.html',
			controller: 'HomeController as hc'
		})
		.state('sell', {
			url:'/sell',
			templateUrl: 'templates/sell.html',
			controller: 'SellController as sc'
		})
		.state('sell.lemonade', {
			url: '/lemonade',
			templateUrl: 'templates/sell-lemonade.html',
			controller: function() {
				this.info = {
					description: 'I love drinking this stuff',
					health: 'Little lemon ... lots of sugar!'
				};
			},
			controllerAs: 'slc'
		})
		.state('sell.healthy', {
			url: '/healthy',
			templateUrl: 'templates/sell-healthy.html',
			controller: function() {
				this.info = {
					description: 'An apple a day keeps the doctor away'
				};
			},
			controllerAs: 'shc'
		})
		.state('sell.treat', {
			url: '/treat',
			templateUrl: 'templates/sell-treat.html',
			controller: function($scope) {
				this.info = {
					lifeSpan: -42
				};
			},
			controllerAs: 'stc'
		});
}]);

/**
 * Home Controller for the home route.
 **/
 app.controller('HomeController', [function() {
 	var hc = this;

 	//Setting the page properties
 	hc.page = {
 		title: 'This one\'s on me'
 	};

 }]);

/**
 * Sell Controller for the sell route.
 **/
 app.controller('SellController', [function() {
 	var sc = this;

 	//Setting the page properties
 	sc.page = {
 		title: 'Sell'
 	};

 	sc.transaction = {
 		largeLemonadeQuantity: 0,
 		mediumLemonadeQuantity: 0,
 		healthySnackQuantity: 0,
 		treatQuantity: 0,
 		transactionQuantity: 0,
 		transactionCost: 0
 	};

 	/**
 	 * Action that clears out the entire transaction.
 	 **/
 	sc.clearTransaction = function() {
 		sc.transaction.largeLemonadeQuantity = 0;
 		sc.transaction.mediumLemonadeQuantity = 0;
 		sc.transaction.healthySnackQuantity = 0;
 		sc.transaction.treatQuantity = 0;
 		sc.transaction.transactionQuantity = 0;
 		sc.transaction.transactionCost = 0;
 	};

 	/** With Controller As **/
 }]);

/**
 * Product Controller handles the interaction with the products.
 **/
app.controller('ProductController', ['$scope', function($scope) {
	var pc = this;

	/**
 	 * Action that increments the quantity of large lemonades 
 	 *  sold in this transaction.
 	 **/
 	pc.incrementLargeLemonade = function() {
 		console.log('pc:' + pc);
 		$scope.sc.transaction.largeLemonadeQuantity++;
 		$scope.sc.transaction.transactionQuantity ++;
 		$scope.sc.transaction.transactionCost += 2;
 	};

 	/**
 	 * Action that increments the quantity of medium lemonades 
 	 *   sold in this transaction.
 	 **/
 	pc.incrementMediumLemonade = function() {
 		$scope.sc.transaction.mediumLemonadeQuantity++;
 		$scope.sc.transaction.transactionQuantity++;
 		$scope.sc.transaction.transactionCost++;
 	};

 	/**
 	 * Action that increments the quantity of healthy snacks 
 	 *   sold in this transaction.
 	 **/
 	pc.incrementHealthySnack = function() {
 		$scope.sc.transaction.healthySnackQuantity++;
 		$scope.sc.transaction.transactionQuantity ++;
 		$scope.sc.transaction.transactionCost++;
 	};

 	/** 
 	 * Action that increments the quantity of treats sold in this
 	 *   transaction.
 	 **/
 	 pc.incrementTreat = function() {
 		$scope.sc.transaction.treatQuantity++;
 		$scope.sc.transaction.transactionQuantity ++;
 		$scope.sc.transaction.transactionCost++;
 	};

}]);